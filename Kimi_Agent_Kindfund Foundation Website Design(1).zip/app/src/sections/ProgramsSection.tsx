import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { BookOpen, Heart, Wrench, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ProgramsSectionProps {
  className?: string;
}

const programs = [
  {
    icon: BookOpen,
    title: 'School supplies & scholarships',
    description: 'Books, fees, and mentorship for girls and boys.',
    image: '/images/programs_education.jpg',
    delay: 0
  },
  {
    icon: Heart,
    title: 'Basic health & nutrition',
    description: 'Checkups, meals, and clean water at school.',
    image: '/images/programs_health.jpg',
    delay: 0.06
  },
  {
    icon: Wrench,
    title: 'Family livelihoods',
    description: 'Training, tools, and micro-loans for parents.',
    image: '/images/programs_livelihoods.jpg',
    delay: 0.10
  }
];

export default function ProgramsSection({ className = '' }: ProgramsSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
        }
      });

      // Phase 1 — ENTRANCE (0%–30%)
      // Label entrance
      scrollTl.fromTo(labelRef.current,
        { y: -20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      );

      // Cards entrance (stagger left→right)
      cardsRef.current.forEach((card, i) => {
        if (card) {
          scrollTl.fromTo(card,
            { y: '80vh', opacity: 0, scale: 0.96 },
            { y: 0, opacity: 1, scale: 1, ease: 'none' },
            programs[i].delay
          );
        }
      });

      // Phase 3 — EXIT (70%–100%)
      // Cards exit (stagger right→left)
      cardsRef.current.reverse().forEach((card, i) => {
        if (card) {
          scrollTl.fromTo(card,
            { y: 0, opacity: 1 },
            { y: '-60vh', opacity: 0, ease: 'power2.in' },
            0.70 + i * 0.03
          );
        }
      });

      // Label exit
      scrollTl.fromTo(labelRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.70
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="programs"
      ref={sectionRef}
      className={`section-pinned ${className}`}
      style={{ backgroundColor: '#F6FBF6' }}
    >
      {/* Label */}
      <span
        ref={labelRef}
        className="absolute left-[6vw] top-[8vh] label-text text-[#2F7A3E]"
        style={{ opacity: 0 }}
      >
        Our Programs
      </span>

      {/* Cards Grid */}
      <div className="absolute inset-0 flex items-center justify-center px-[5vw]">
        <div className="flex gap-[3vw] w-full max-w-[90vw]">
          {programs.map((program, index) => (
            <div
              key={program.title}
              ref={el => { cardsRef.current[index] = el; }}
              className={`flex-1 bg-white card-rounded card-shadow overflow-hidden ambient-float${index > 0 ? `-delay-${index}` : ''}`}
              style={{ 
                opacity: 0,
                height: '68vh',
                maxHeight: '600px'
              }}
            >
              {/* Image */}
              <div className="h-[45%] overflow-hidden">
                <img
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>

              {/* Content */}
              <div className="p-6 flex flex-col h-[55%]">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-full bg-[#2F7A3E]/10 flex items-center justify-center">
                    <program.icon className="w-4 h-4 text-[#2F7A3E]" />
                  </div>
                  <span className="text-xs font-mono uppercase tracking-wider text-[#4A5D4E]">
                    Program {String(index + 1).padStart(2, '0')}
                  </span>
                </div>

                <h3 className="font-heading font-bold text-[clamp(18px,1.8vw,26px)] text-[#0F1A12] leading-tight mb-3">
                  {program.title}
                </h3>

                <p className="text-[clamp(14px,1vw,16px)] text-[#4A5D4E] leading-relaxed flex-1">
                  {program.description}
                </p>

                <button className="flex items-center gap-2 text-[#2F7A3E] font-medium text-sm hover:gap-3 transition-all mt-4">
                  Learn more
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
