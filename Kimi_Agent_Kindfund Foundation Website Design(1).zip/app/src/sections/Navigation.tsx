import { useEffect, useState, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Heart } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Navigation() {
  const [isVisible, setIsVisible] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const showNav = () => {
      setIsVisible(window.scrollY > window.innerHeight * 0.5);
    };

    window.addEventListener('scroll', showNav, { passive: true });
    return () => window.removeEventListener('scroll', showNav);
  }, []);

  useEffect(() => {
    if (navRef.current) {
      gsap.to(navRef.current, {
        y: isVisible ? 0 : -100,
        opacity: isVisible ? 1 : 0,
        duration: 0.3,
        ease: 'power2.out'
      });
    }
  }, [isVisible]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 right-0 z-[100] px-6 py-4"
      style={{ 
        background: 'rgba(246, 251, 246, 0.92)',
        backdropFilter: 'blur(12px)',
        transform: 'translateY(-100%)',
        opacity: 0
      }}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <button 
          onClick={() => scrollToSection('hero')}
          className="font-heading font-bold text-xl text-[#0F1A12] hover:text-[#2F7A3E] transition-colors"
        >
          Kindfund
        </button>

        {/* Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          <button 
            onClick={() => scrollToSection('programs')}
            className="text-sm font-medium text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors"
          >
            Programs
          </button>
          <button 
            onClick={() => scrollToSection('stories')}
            className="text-sm font-medium text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors"
          >
            Stories
          </button>
          <button 
            onClick={() => scrollToSection('transparency')}
            className="text-sm font-medium text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors"
          >
            Transparency
          </button>
          <button 
            onClick={() => scrollToSection('contact')}
            className="text-sm font-medium text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors"
          >
            Contact
          </button>
        </div>

        {/* Donate Button */}
        <button 
          onClick={() => scrollToSection('contact')}
          className="flex items-center gap-2 px-5 py-2.5 bg-[#2F7A3E] text-white text-sm font-medium rounded-full btn-hover"
        >
          <Heart className="w-4 h-4" />
          Donate
        </button>
      </div>
    </nav>
  );
}
