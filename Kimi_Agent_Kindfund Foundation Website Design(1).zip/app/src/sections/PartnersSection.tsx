import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Building2, School, HeartHandshake, Globe, TreePine, Coffee } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const partners = [
  { name: 'GreenCorp', icon: TreePine },
  { name: 'EduFirst', icon: School },
  { name: 'GlobalAid', icon: Globe },
  { name: 'Community Care', icon: HeartHandshake },
  { name: 'BuildBetter', icon: Building2 },
  { name: 'FairTrade Co', icon: Coffee },
  { name: 'EcoFund', icon: TreePine },
  { name: 'LearnWell', icon: School }
];

export default function PartnersSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const tilesRef = useRef<(HTMLDivElement | null)[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline reveal
      gsap.fromTo(headlineRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Tiles staggered reveal
      tilesRef.current.forEach((tile, i) => {
        if (tile) {
          gsap.fromTo(tile,
            { y: 40, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.5,
              delay: i * 0.06,
              scrollTrigger: {
                trigger: section,
                start: 'top 70%',
                toggleActions: 'play none none reverse'
              }
            }
          );
        }
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 md:py-32"
      style={{ backgroundColor: '#F6FBF6' }}
    >
      <div className="max-w-6xl mx-auto px-6">
        {/* Headline */}
        <div ref={headlineRef} className="text-center mb-16" style={{ opacity: 0 }}>
          <span className="label-text text-[#2F7A3E] mb-4 block">Partners</span>
          <h2 className="font-heading font-extrabold text-[clamp(28px,3vw,48px)] text-[#0F1A12] leading-tight tracking-[-0.02em] mb-4">
            Powered by people like you.
          </h2>
          <p className="text-[clamp(15px,1.2vw,18px)] text-[#4A5D4E] max-w-xl mx-auto">
            Companies, schools, and communities helping us grow.
          </p>
        </div>

        {/* Logo Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {partners.map((partner, index) => (
            <div
              key={partner.name}
              ref={el => { tilesRef.current[index] = el; }}
              className="bg-white card-rounded border border-[#0F1A12]/8 p-6 md:p-8 flex flex-col items-center justify-center gap-4 hover:shadow-lg hover:-translate-y-1 transition-all cursor-pointer"
              style={{ opacity: 0 }}
            >
              <div className="w-12 h-12 rounded-full bg-[#2F7A3E]/10 flex items-center justify-center">
                <partner.icon className="w-6 h-6 text-[#2F7A3E]" />
              </div>
              <span className="font-medium text-[#0F1A12] text-sm md:text-base">{partner.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
