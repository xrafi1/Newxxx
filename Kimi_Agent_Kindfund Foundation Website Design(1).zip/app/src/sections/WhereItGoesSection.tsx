import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface WhereItGoesSectionProps {
  className?: string;
}

export default function WhereItGoesSection({ className = '' }: WhereItGoesSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const statPillRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
        }
      });

      // Phase 1 — ENTRANCE (0%–30%)
      // Text card entrance
      scrollTl.fromTo(cardRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Stat pill entrance
      scrollTl.fromTo(statPillRef.current,
        { x: '-40vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.06
      );

      // Background parallax during settle
      scrollTl.fromTo(bgRef.current,
        { scale: 1.05 },
        { scale: 1, ease: 'none' },
        0.30
      );

      // Phase 3 — EXIT (70%–100%)
      scrollTl.fromTo(cardRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(statPillRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="where-it-goes"
      ref={sectionRef}
      className={`section-pinned ${className}`}
      style={{ backgroundColor: '#F6FBF6' }}
    >
      {/* Background Image */}
      <div ref={bgRef} className="absolute inset-0 w-full h-full">
        <img
          src="/images/seedling_hands.jpg"
          alt="Hands holding a seedling"
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay for text legibility */}
        <div className="absolute inset-0 gradient-right" />
      </div>

      {/* Right Text Card */}
      <div
        ref={cardRef}
        className="absolute right-[6vw] top-[18vh] w-[40vw] min-h-[56vh] bg-white/95 backdrop-blur-sm card-rounded card-shadow p-[6%_8%] flex flex-col justify-center"
        style={{ opacity: 0 }}
      >
        <span className="label-text text-[#2F7A3E] mb-4">Where It Goes</span>
        <h2 className="font-heading font-extrabold text-[clamp(34px,3.6vw,56px)] text-[#0F1A12] leading-[1.0] tracking-[-0.02em] mb-6">
          Every dollar plants roots.
        </h2>
        <p className="text-[clamp(15px,1.2vw,18px)] text-[#4A5D4E] leading-relaxed mb-8">
          We partner with local teams who know their communities. Overhead is kept minimal; receipts are published monthly.
        </p>
        <button 
          onClick={() => document.getElementById('transparency')?.scrollIntoView({ behavior: 'smooth' })}
          className="flex items-center gap-2 text-[#2F7A3E] font-medium hover:gap-3 transition-all"
        >
          See the breakdown
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Bottom-left Stat Pill */}
      <div
        ref={statPillRef}
        className="absolute left-[6vw] bottom-[10vh] px-8 py-5 bg-white/95 backdrop-blur-sm rounded-full card-shadow flex items-center gap-4"
        style={{ opacity: 0 }}
      >
        <div className="w-12 h-12 rounded-full bg-[#2F7A3E]/10 flex items-center justify-center">
          <span className="font-heading font-bold text-lg text-[#2F7A3E]">98%</span>
        </div>
        <span className="text-[#0F1A12] font-medium">directly funds local programs</span>
      </div>
    </section>
  );
}
