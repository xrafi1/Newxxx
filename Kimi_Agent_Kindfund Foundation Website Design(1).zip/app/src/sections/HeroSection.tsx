import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Heart } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  className?: string;
}

export default function HeroSection({ className = '' }: HeroSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const wordmarkRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const headline1Ref = useRef<HTMLHeadingElement>(null);
  const headline2Ref = useRef<HTMLHeadingElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on mount
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      // Background fade in
      tl.fromTo(bgRef.current,
        { opacity: 0, scale: 1.06 },
        { opacity: 1, scale: 1, duration: 0.9 }
      );

      // Wordmark + nav
      tl.fromTo([wordmarkRef.current, navRef.current],
        { y: -12, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, stagger: 0.08 },
        '-=0.5'
      );

      // Label → Headlines → Subheadline
      tl.fromTo(labelRef.current,
        { x: -40, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.6 },
        '-=0.3'
      );

      tl.fromTo(headline1Ref.current,
        { x: -40, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.6 },
        '-=0.45'
      );

      tl.fromTo(headline2Ref.current,
        { x: -40, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.6 },
        '-=0.45'
      );

      tl.fromTo(subheadRef.current,
        { x: -40, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.6 },
        '-=0.45'
      );

      // CTAs + stats
      tl.fromTo([ctaRef.current, statsRef.current],
        { y: 16, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, stagger: 0.06 },
        '-=0.3'
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.set([contentRef.current, ctaRef.current, statsRef.current], {
              opacity: 1, x: 0, y: 0
            });
            gsap.set(bgRef.current, { scale: 1, x: 0 });
          }
        }
      });

      // Phase 1 (0%-30%): Hold - elements already in place from entrance
      // Phase 2 (30%-70%): Settle - static

      // Phase 3 (70%-100%): Exit
      // Headline block exit
      scrollTl.fromTo(contentRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      // Background parallax
      scrollTl.fromTo(bgRef.current,
        { scale: 1, x: 0 },
        { scale: 1.08, x: '6vw', ease: 'none' },
        0.70
      );

      // CTAs exit
      scrollTl.fromTo(ctaRef.current,
        { y: 0, opacity: 1 },
        { y: '10vh', opacity: 0, ease: 'power2.in' },
        0.70
      );

      // Stats exit
      scrollTl.fromTo(statsRef.current,
        { y: 0, opacity: 1 },
        { y: '10vh', opacity: 0, ease: 'power2.in' },
        0.72
      );

    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToPrograms = () => {
    const element = document.getElementById('programs');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      ref={sectionRef}
      className={`section-pinned ${className}`}
      style={{ backgroundColor: '#F6FBF6' }}
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 w-full h-full"
        style={{ opacity: 0 }}
      >
        <img
          src="/images/hero_hands_field.jpg"
          alt="Hands holding green leaves"
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay for text legibility */}
        <div className="absolute inset-0 gradient-left" />
      </div>

      {/* Wordmark */}
      <div
        ref={wordmarkRef}
        className="absolute left-[4vw] top-[4vh] z-10"
        style={{ opacity: 0 }}
      >
        <span className="font-heading font-bold text-xl text-[#0F1A12]">Kindfund</span>
      </div>

      {/* Nav */}
      <div
        ref={navRef}
        className="absolute right-[4vw] top-[4.2vh] z-10 hidden md:flex items-center gap-8"
        style={{ opacity: 0 }}
      >
        <button onClick={scrollToPrograms} className="text-sm font-medium text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors">
          Programs
        </button>
        <button onClick={() => document.getElementById('stories')?.scrollIntoView({ behavior: 'smooth' })} className="text-sm font-medium text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors">
          Stories
        </button>
        <button onClick={() => document.getElementById('transparency')?.scrollIntoView({ behavior: 'smooth' })} className="text-sm font-medium text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors">
          Transparency
        </button>
        <button onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })} className="text-sm font-medium text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors">
          Contact
        </button>
      </div>

      {/* Content */}
      <div className="absolute inset-0 flex items-center">
        <div ref={contentRef} className="w-full max-w-7xl mx-auto px-[8vw]">
          {/* Label */}
          <span
            ref={labelRef}
            className="label-text text-[#2F7A3E] block mb-4"
            style={{ opacity: 0 }}
          >
            Kindfund Foundation
          </span>

          {/* Headlines */}
          <h1
            ref={headline1Ref}
            className="font-heading font-extrabold text-[clamp(44px,5vw,78px)] text-[#0F1A12] leading-[0.95] tracking-[-0.02em]"
            style={{ opacity: 0 }}
          >
            Small acts,
          </h1>
          <h1
            ref={headline2Ref}
            className="font-heading font-extrabold text-[clamp(44px,5vw,78px)] text-[#0F1A12] leading-[0.95] tracking-[-0.02em] mt-2"
            style={{ opacity: 0 }}
          >
            multiplied.
          </h1>

          {/* Subheadline */}
          <p
            ref={subheadRef}
            className="mt-8 text-[clamp(15px,1.2vw,18px)] text-[#4A5D4E] max-w-[34vw] leading-relaxed"
            style={{ opacity: 0 }}
          >
            We connect donors to local leaders—no waste, full transparency.
          </p>

          {/* CTAs */}
          <div
            ref={ctaRef}
            className="mt-10 flex items-center gap-4 flex-wrap"
            style={{ opacity: 0 }}
          >
            <button
              onClick={scrollToContact}
              className="flex items-center gap-2 px-6 py-3.5 bg-[#2F7A3E] text-white font-medium rounded-full btn-hover"
            >
              <Heart className="w-4 h-4" />
              Donate monthly
            </button>
            <button
              onClick={scrollToPrograms}
              className="flex items-center gap-2 px-6 py-3.5 bg-white/80 text-[#0F1A12] font-medium rounded-full border border-[#0F1A12]/10 btn-hover hover:bg-white"
            >
              See our programs
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Micro Stats */}
      <div
        ref={statsRef}
        className="absolute left-[8vw] bottom-[7vh] flex items-center gap-6"
        style={{ opacity: 0 }}
      >
        <div className="flex items-center gap-2">
          <span className="font-heading font-bold text-2xl text-[#2F7A3E]">98%</span>
          <span className="text-sm text-[#4A5D4E]">to programs</span>
        </div>
        <div className="w-px h-8 bg-[#0F1A12]/10" />
        <div className="flex items-center gap-2">
          <span className="font-heading font-bold text-2xl text-[#2F7A3E]">12</span>
          <span className="text-sm text-[#4A5D4E]">countries</span>
        </div>
      </div>
    </section>
  );
}
