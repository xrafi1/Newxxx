import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface TransparencySectionProps {
  className?: string;
}

const breakdown = [
  { label: 'Programs', percentage: 78, color: '#2F7A3E' },
  { label: 'Local logistics', percentage: 20, color: '#5A9A68' },
  { label: 'Admin & legal', percentage: 2, color: '#8FBA99' }
];

export default function TransparencySection({ className = '' }: TransparencySectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const reportCardRef = useRef<HTMLDivElement>(null);
  const progressRefs = useRef<(HTMLDivElement | null)[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
        }
      });

      // Phase 1 — ENTRANCE (0%–30%)
      // Report card entrance
      scrollTl.fromTo(reportCardRef.current,
        { x: '60vw', opacity: 0, rotate: 1 },
        { x: 0, opacity: 1, rotate: 0, ease: 'none' },
        0
      );

      // Headline entrance
      scrollTl.fromTo(headlineRef.current,
        { x: '-30vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.06
      );

      // Progress bars (staggered)
      progressRefs.current.forEach((bar, i) => {
        if (bar) {
          scrollTl.fromTo(bar,
            { scaleX: 0 },
            { scaleX: 1, ease: 'none', transformOrigin: 'left' },
            0.14 + i * 0.04
          );
        }
      });

      // Phase 3 — EXIT (70%–100%)
      scrollTl.fromTo(reportCardRef.current,
        { y: 0, opacity: 1 },
        { y: '-40vh', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(headlineRef.current,
        { y: 0, opacity: 1 },
        { y: '18vh', opacity: 0, ease: 'power2.in' },
        0.70
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="transparency"
      ref={sectionRef}
      className={`section-pinned ${className}`}
      style={{ backgroundColor: '#E9F3EB' }}
    >
      {/* Left Headline Block */}
      <div
        ref={headlineRef}
        className="absolute left-[6vw] top-[12vh] max-w-[34vw]"
        style={{ opacity: 0 }}
      >
        <span className="label-text text-[#2F7A3E] mb-4 block">Transparency</span>
        <h2 className="font-heading font-extrabold text-[clamp(34px,3.6vw,56px)] text-[#0F1A12] leading-[1.0] tracking-[-0.02em] mb-6">
          You see what we see.
        </h2>
        <p className="text-[clamp(15px,1.2vw,18px)] text-[#4A5D4E] leading-relaxed max-w-[30vw]">
          Monthly reports, receipts, and program updates—published for every project.
        </p>
      </div>

      {/* Right Report Card */}
      <div
        ref={reportCardRef}
        className="absolute right-[6vw] top-[16vh] w-[46vw] min-h-[66vh] bg-white card-rounded card-shadow p-8 flex flex-col justify-center"
        style={{ opacity: 0 }}
      >
        <h3 className="font-heading font-bold text-2xl text-[#0F1A12] mb-8">
          Where your donation goes
        </h3>

        <div className="space-y-8">
          {breakdown.map((item, index) => (
            <div key={item.label}>
              <div className="flex justify-between items-center mb-3">
                <span className="font-medium text-[#0F1A12]">{item.label}</span>
                <span className="font-heading font-bold text-xl" style={{ color: item.color }}>
                  {item.percentage}%
                </span>
              </div>
              <div className="h-3 bg-[#E9F3EB] rounded-full overflow-hidden">
                <div
                  ref={el => { progressRefs.current[index] = el; }}
                  className="h-full rounded-full progress-bar"
                  style={{ 
                    backgroundColor: item.color,
                    width: `${item.percentage}%`,
                    transform: 'scaleX(0)',
                    transformOrigin: 'left'
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 pt-6 border-t border-[#0F1A12]/10">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#4A5D4E]">Last updated</span>
            <span className="text-sm font-medium text-[#0F1A12]">February 2026</span>
          </div>
          <button className="mt-4 w-full py-3 border border-[#2F7A3E] text-[#2F7A3E] rounded-full font-medium hover:bg-[#2F7A3E] hover:text-white transition-colors">
            Download full report
          </button>
        </div>
      </div>
    </section>
  );
}
