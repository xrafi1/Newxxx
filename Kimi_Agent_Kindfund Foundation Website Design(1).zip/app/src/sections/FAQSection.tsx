import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown, Mail } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const faqs = [
  {
    question: 'How much of my donation reaches the field?',
    answer: '98% of every donation goes directly to our programs. Only 2% is used for administrative costs, and we publish detailed monthly reports showing exactly where every dollar goes.'
  },
  {
    question: 'Can I choose a country or program?',
    answer: 'Yes! When you donate, you can specify which program (Education, Health, or Livelihoods) you\'d like to support, or let us allocate it where it\'s needed most.'
  },
  {
    question: 'Is my donation tax-deductible?',
    answer: 'Yes, Kindfund Foundation is a registered 501(c)(3) nonprofit organization. All donations are tax-deductible in the United States, and we provide receipts for your records.'
  },
  {
    question: 'How do I update or cancel monthly giving?',
    answer: 'You can manage your monthly donation anytime through your donor dashboard, or simply email us at hello@kindfund.org and we\'ll help you make changes.'
  },
  {
    question: 'Do you share my information?',
    answer: 'Never. We respect your privacy and will never sell or share your personal information with third parties. You can read our full privacy policy for more details.'
  }
];

export default function FAQSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const itemsRef = useRef<(HTMLDivElement | null)[]>([]);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Left column reveal
      gsap.fromTo(leftRef.current,
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Accordion items reveal
      itemsRef.current.forEach((item, i) => {
        if (item) {
          gsap.fromTo(item,
            { y: 30, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.5,
              delay: i * 0.08,
              scrollTrigger: {
                trigger: section,
                start: 'top 70%',
                toggleActions: 'play none none reverse'
              }
            }
          );
        }
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section
      ref={sectionRef}
      className="relative py-24 md:py-32"
      style={{ backgroundColor: '#F6FBF6' }}
    >
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-[1fr_1.7fr] gap-12 md:gap-16">
          {/* Left Column - Sticky */}
          <div ref={leftRef} className="md:sticky md:top-24 md:self-start" style={{ opacity: 0 }}>
            <span className="label-text text-[#2F7A3E] mb-4 block">FAQ</span>
            <h2 className="font-heading font-extrabold text-[clamp(28px,3vw,48px)] text-[#0F1A12] leading-tight tracking-[-0.02em] mb-4">
              Questions?
            </h2>
            <p className="text-[clamp(15px,1.2vw,18px)] text-[#4A5D4E] mb-6">
              If you need more help, email us.
            </p>
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="flex items-center gap-2 px-6 py-3 bg-[#2F7A3E] text-white font-medium rounded-full btn-hover"
            >
              <Mail className="w-4 h-4" />
              Contact us
            </button>
          </div>

          {/* Right Column - Accordion */}
          <div className="space-y-0">
            {faqs.map((faq, index) => (
              <div
                key={index}
                ref={el => { itemsRef.current[index] = el; }}
                className="border-b border-[#0F1A12]/10"
                style={{ opacity: 0 }}
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full py-5 flex items-center justify-between text-left group"
                >
                  <span className="font-medium text-[#0F1A12] pr-4 group-hover:text-[#2F7A3E] transition-colors">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-[#4A5D4E] flex-shrink-0 transition-transform ${
                      openIndex === index ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-48 pb-5' : 'max-h-0'
                  }`}
                >
                  <p className="text-[#4A5D4E] leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
