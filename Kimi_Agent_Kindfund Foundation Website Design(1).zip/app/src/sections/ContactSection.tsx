import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Phone, MapPin, Heart, Download, ArrowRight } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

gsap.registerPlugin(ScrollTrigger);

const contactCards = [
  {
    icon: Mail,
    label: 'Email us',
    value: 'hello@kindfund.org',
    href: 'mailto:hello@kindfund.org'
  },
  {
    icon: Phone,
    label: 'Call us',
    value: '+1 (555) 014-2200',
    href: 'tel:+15550142200'
  },
  {
    icon: MapPin,
    label: 'Visit us',
    value: '123 Greenway Ave, Portland, OR',
    href: '#'
  }
];

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLAnchorElement | null)[]>([]);
  const ctaRef = useRef<HTMLDivElement>(null);
  const [donateOpen, setDonateOpen] = useState(false);
  const [amount, setAmount] = useState<string>('50');
  const [customAmount, setCustomAmount] = useState('');

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline reveal
      gsap.fromTo(headlineRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Cards reveal
      cardsRef.current.forEach((card, i) => {
        if (card) {
          gsap.fromTo(card,
            { y: 50, opacity: 0, scale: 0.98 },
            {
              y: 0,
              opacity: 1,
              scale: 1,
              duration: 0.5,
              delay: i * 0.08,
              scrollTrigger: {
                trigger: section,
                start: 'top 70%',
                toggleActions: 'play none none reverse'
              }
            }
          );
        }
      });

      // CTA reveal
      gsap.fromTo(ctaRef.current,
        { y: 18, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          delay: 0.3,
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleDonate = () => {
    setDonateOpen(false);
    alert(`Thank you for your $${amount === 'custom' ? customAmount : amount} donation! This is a demo.`);
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-24 md:py-32"
      style={{ backgroundColor: '#E9F3EB' }}
    >
      <div className="max-w-6xl mx-auto px-6">
        {/* Headline */}
        <div ref={headlineRef} className="text-center mb-16" style={{ opacity: 0 }}>
          <span className="label-text text-[#2F7A3E] mb-4 block">Contact</span>
          <h2 className="font-heading font-extrabold text-[clamp(34px,3.6vw,56px)] text-[#0F1A12] leading-tight tracking-[-0.02em]">
            Ready to help?
          </h2>
        </div>

        {/* Contact Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {contactCards.map((card, index) => (
            <a
              key={card.label}
              ref={el => { cardsRef.current[index] = el; }}
              href={card.href}
              className="bg-white card-rounded card-shadow p-8 flex flex-col items-center text-center hover:shadow-lg hover:-translate-y-1 transition-all group"
              style={{ opacity: 0 }}
            >
              <div className="w-14 h-14 rounded-full bg-[#2F7A3E]/10 flex items-center justify-center mb-4 group-hover:bg-[#2F7A3E] transition-colors">
                <card.icon className="w-6 h-6 text-[#2F7A3E] group-hover:text-white transition-colors" />
              </div>
              <span className="text-sm text-[#4A5D4E] mb-1">{card.label}</span>
              <span className="font-medium text-[#0F1A12]">{card.value}</span>
            </a>
          ))}
        </div>

        {/* CTA Block */}
        <div ref={ctaRef} className="text-center" style={{ opacity: 0 }}>
          <button
            onClick={() => setDonateOpen(true)}
            className="inline-flex items-center gap-2 px-8 py-4 bg-[#2F7A3E] text-white font-medium rounded-full btn-hover text-lg mb-4"
          >
            <Heart className="w-5 h-5" />
            Donate now
          </button>
          <div>
            <button className="inline-flex items-center gap-2 text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors">
              <Download className="w-4 h-4" />
              Download annual report (PDF)
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-24 pt-8 border-t border-[#0F1A12]/10">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="font-heading font-bold text-lg text-[#0F1A12]">Kindfund</span>
            </div>
            <p className="text-sm text-[#4A5D4E]">
              © Kindfund Foundation. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-sm text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors">Privacy</a>
              <a href="#" className="text-sm text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors">Terms</a>
              <a href="#" className="text-sm text-[#4A5D4E] hover:text-[#2F7A3E] transition-colors">Accessibility</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Donate Dialog */}
      <Dialog open={donateOpen} onOpenChange={setDonateOpen}>
        <DialogContent className="sm:max-w-md bg-white">
          <DialogHeader>
            <DialogTitle className="font-heading font-bold text-2xl text-[#0F1A12]">
              Make a Donation
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 pt-4">
            <div>
              <label className="text-sm text-[#4A5D4E] mb-3 block">Select amount</label>
              <div className="grid grid-cols-4 gap-3">
                {['25', '50', '100', '250'].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setAmount(amt)}
                    className={`py-3 rounded-xl font-medium transition-colors ${
                      amount === amt
                        ? 'bg-[#2F7A3E] text-white'
                        : 'bg-[#F6FBF6] text-[#0F1A12] hover:bg-[#E9F3EB]'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label className="text-sm text-[#4A5D4E] mb-2 block">Or enter custom amount</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#4A5D4E]">$</span>
                <input
                  type="number"
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                    setAmount('custom');
                  }}
                  placeholder="Other amount"
                  className="w-full pl-8 pr-4 py-3 bg-[#F6FBF6] border border-[#0F1A12]/10 rounded-xl text-[#0F1A12] focus:outline-none focus:border-[#2F7A3E] focus:ring-2 focus:ring-[#2F7A3E]/20"
                />
              </div>
            </div>

            <button
              onClick={handleDonate}
              className="w-full py-4 bg-[#2F7A3E] text-white font-medium rounded-xl btn-hover flex items-center justify-center gap-2"
            >
              Donate ${amount === 'custom' ? (customAmount || '0') : amount}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}
