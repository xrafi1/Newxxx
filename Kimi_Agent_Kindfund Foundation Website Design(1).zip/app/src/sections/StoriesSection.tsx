import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface StoriesSectionProps {
  className?: string;
}

export default function StoriesSection({ className = '' }: StoriesSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const storyCardRef = useRef<HTMLDivElement>(null);
  const quoteCardRef = useRef<HTMLDivElement>(null);
  const quoteTextRef = useRef<HTMLParagraphElement>(null);
  const quoteAttrRef = useRef<HTMLSpanElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
        }
      });

      // Phase 1 — ENTRANCE (0%–30%)
      // Story card entrance
      scrollTl.fromTo(storyCardRef.current,
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Quote card background plate
      scrollTl.fromTo(quoteCardRef.current,
        { scaleX: 0 },
        { scaleX: 1, ease: 'none', transformOrigin: 'left' },
        0
      );

      // Quote text
      scrollTl.fromTo(quoteTextRef.current,
        { y: 14, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.10
      );

      // Attribution
      scrollTl.fromTo(quoteAttrRef.current,
        { opacity: 0 },
        { opacity: 1, ease: 'none' },
        0.16
      );

      // Background parallax during settle
      scrollTl.fromTo(bgRef.current,
        { scale: 1.06 },
        { scale: 1, ease: 'none' },
        0.30
      );

      // Phase 3 — EXIT (70%–100%)
      scrollTl.fromTo(storyCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(quoteCardRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="stories"
      ref={sectionRef}
      className={`section-pinned ${className}`}
      style={{ backgroundColor: '#F6FBF6' }}
    >
      {/* Background Image */}
      <div ref={bgRef} className="absolute inset-0 w-full h-full">
        <img
          src="/images/story_amina.jpg"
          alt="Amina - a student with dreams"
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay for text legibility */}
        <div className="absolute inset-0 gradient-left" />
      </div>

      {/* Left Story Card */}
      <div
        ref={storyCardRef}
        className="absolute left-[6vw] top-[18vh] w-[40vw] min-h-[56vh] bg-white/95 backdrop-blur-sm card-rounded card-shadow p-[6%_8%] flex flex-col justify-center"
        style={{ opacity: 0 }}
      >
        <span className="label-text text-[#2F7A3E] mb-4">Stories</span>
        <h2 className="font-heading font-extrabold text-[clamp(34px,3.6vw,56px)] text-[#0F1A12] leading-[1.0] tracking-[-0.02em] mb-6">
          "I want to be a teacher."
        </h2>
        <p className="text-[clamp(15px,1.2vw,18px)] text-[#4A5D4E] leading-relaxed mb-8">
          Amina's family struggled with school fees. A small monthly scholarship changed her trajectory.
        </p>
        <button className="flex items-center gap-2 text-[#2F7A3E] font-medium hover:gap-3 transition-all">
          Read her story
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Bottom-right Quote Card */}
      <div
        ref={quoteCardRef}
        className="absolute right-[6vw] bottom-[10vh] w-[34vw] p-[2.2vh_2.4vw] card-rounded bg-white/80 backdrop-blur-sm"
        style={{ transformOrigin: 'left' }}
      >
        <div className="flex items-start gap-3">
          <Quote className="w-6 h-6 text-[#2F7A3E] flex-shrink-0 mt-1" />
          <div>
            <p
              ref={quoteTextRef}
              className="font-heading font-bold text-xl text-[#0F1A12] mb-2"
              style={{ opacity: 0 }}
            >
              "Now I can finish school."
            </p>
            <span
              ref={quoteAttrRef}
              className="text-sm text-[#4A5D4E]"
              style={{ opacity: 0 }}
            >
              — Amina, 12
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
