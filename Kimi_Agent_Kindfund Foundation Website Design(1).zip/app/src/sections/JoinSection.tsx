import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Instagram, Youtube, Linkedin, Mail } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface JoinSectionProps {
  className?: string;
}

export default function JoinSection({ className = '' }: JoinSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const formCardRef = useRef<HTMLDivElement>(null);
  const socialCardRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          anticipatePin: 1,
        }
      });

      // Phase 1 — ENTRANCE (0%–30%)
      // Form card entrance
      scrollTl.fromTo(formCardRef.current,
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Social card background plate
      scrollTl.fromTo(socialCardRef.current,
        { scaleX: 0 },
        { scaleX: 1, ease: 'none', transformOrigin: 'left' },
        0
      );

      // Background parallax during settle
      scrollTl.fromTo(bgRef.current,
        { scale: 1.06 },
        { scale: 1, ease: 'none' },
        0.30
      );

      // Phase 3 — EXIT (70%–100%)
      scrollTl.fromTo(formCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(socialCardRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => {
        setEmail('');
        setSubscribed(false);
      }, 3000);
    }
  };

  return (
    <section
      id="join"
      ref={sectionRef}
      className={`section-pinned ${className}`}
      style={{ backgroundColor: '#F6FBF6' }}
    >
      {/* Background Image */}
      <div ref={bgRef} className="absolute inset-0 w-full h-full">
        <img
          src="/images/join_group.jpg"
          alt="Group of children"
          className="w-full h-full object-cover"
        />
        {/* Gradient overlay for text legibility */}
        <div className="absolute inset-0 gradient-left" />
      </div>

      {/* Left Form Card */}
      <div
        ref={formCardRef}
        className="absolute left-[6vw] top-[18vh] w-[42vw] min-h-[56vh] bg-white/95 backdrop-blur-sm card-rounded card-shadow p-[6%_8%] flex flex-col justify-center"
        style={{ opacity: 0 }}
      >
        <span className="label-text text-[#2F7A3E] mb-4">Join</span>
        <h2 className="font-heading font-extrabold text-[clamp(34px,3.6vw,56px)] text-[#0F1A12] leading-[1.0] tracking-[-0.02em] mb-4">
          Stay in the loop.
        </h2>
        <p className="text-[clamp(15px,1.2vw,18px)] text-[#4A5D4E] leading-relaxed mb-8">
          Get monthly updates—no noise, no spam.
        </p>

        <form onSubmit={handleSubscribe} className="mb-6">
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#4A5D4E]" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email address"
                className="w-full pl-12 pr-4 py-3.5 bg-[#F6FBF6] border border-[#0F1A12]/10 rounded-full text-[#0F1A12] placeholder:text-[#4A5D4E]/60 focus:outline-none focus:border-[#2F7A3E] focus:ring-2 focus:ring-[#2F7A3E]/20"
                required
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3.5 bg-[#2F7A3E] text-white font-medium rounded-full btn-hover"
            >
              {subscribed ? 'Subscribed!' : 'Subscribe'}
            </button>
          </div>
        </form>

        <button className="flex items-center gap-2 text-[#2F7A3E] font-medium hover:gap-3 transition-all">
          Become a volunteer
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Bottom-right Social Card */}
      <div
        ref={socialCardRef}
        className="absolute right-[6vw] bottom-[10vh] w-[34vw] p-[2.2vh_2.4vw] card-rounded bg-white/80 backdrop-blur-sm"
        style={{ transformOrigin: 'left' }}
      >
        <p className="text-sm text-[#4A5D4E] mb-4">Follow the journey</p>
        <div className="flex items-center gap-4">
          <a
            href="#"
            className="w-10 h-10 rounded-full bg-[#2F7A3E]/10 flex items-center justify-center hover:bg-[#2F7A3E] hover:text-white text-[#2F7A3E] transition-colors"
          >
            <Instagram className="w-5 h-5" />
          </a>
          <a
            href="#"
            className="w-10 h-10 rounded-full bg-[#2F7A3E]/10 flex items-center justify-center hover:bg-[#2F7A3E] hover:text-white text-[#2F7A3E] transition-colors"
          >
            <Youtube className="w-5 h-5" />
          </a>
          <a
            href="#"
            className="w-10 h-10 rounded-full bg-[#2F7A3E]/10 flex items-center justify-center hover:bg-[#2F7A3E] hover:text-white text-[#2F7A3E] transition-colors"
          >
            <Linkedin className="w-5 h-5" />
          </a>
        </div>
      </div>
    </section>
  );
}
